﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GitTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World of Git");
            Console.WriteLine("Good Bye");
            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
        }
    }
}
