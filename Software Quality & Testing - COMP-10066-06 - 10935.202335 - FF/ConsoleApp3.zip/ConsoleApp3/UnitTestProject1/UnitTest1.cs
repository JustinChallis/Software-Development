﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace COMP10066Lab5.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestIsUnique_unique()
        {
            List<int> arraySet = new List<int>() { 12, 22, 33, 44, 55 };
            bool expResult = true;
            bool result = ArraySetUtilities.IsUnique(arraySet);
            Assert.AreEqual(expResult, result,
            "Unique Array test returning false - Test array in unique");
        }
    }
}
