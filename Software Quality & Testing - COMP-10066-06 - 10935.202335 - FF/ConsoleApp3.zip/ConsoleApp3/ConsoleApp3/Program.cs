﻿using System;
using System.Collections.Generic;


namespace COMP10066_Assignment4
{
    /// <summary>
    /// A set of utilities that will perform Set-based operations on List<int> datasets
    /// </summary>
    public sealed class ArraySetUtilities
    {
        /// <summary>
        /// Will create a List of integers within an inclusive range. 
        /// Option to generate unique elements is included
        /// </summary>
        /// <param name="size">Number of elements (must be > 1)</param>
        /// <param name="minimum">Minimum value for the integers to generate, inclusive</param>
        /// <param name="maximum">Maximum value for the integers to generate, inclusive</param>
        /// <param name="containsUnique">Whether elements must be unique</param>
        /// <returns>List of Integers with the inclusive range given.  List will be unique (contain no duplicates) if containsUnique is true</returns>
        public static List<int> CreateSet(int size, int minimum, int maximum, bool containsUnique)
        {
            bool filled = false;

            List<int> arraySet = null;
            Random random = new Random();
            if (size <= 1)
                throw new ArgumentException("invalid size specified");
            if (containsUnique && (maximum - minimum) < size)
                throw new ArgumentException("range not large enough for unique set");

            if (containsUnique)
            {
                int rangeSize = maximum - minimum + 1;
                int[] rawNumbers = new int[rangeSize];
                for (int i = 0; i < rangeSize; i++)
                    rawNumbers[i] = minimum + i;
                arraySet = new List<int>();
                for (int i = 0; i < size; i++)
                {
                    int randIndex = random.Next(0, rangeSize - i);
                    arraySet.Add(rawNumbers[randIndex]);
                    int temp = rawNumbers[rangeSize - 1 - i];
                    rawNumbers[rangeSize - 1 - i] = rawNumbers[randIndex];
                    rawNumbers[randIndex] = temp;
                }
            }
            else
            {
                // Non-Unique case 
                int i = 0;
                arraySet = new List<int>();
                while (!filled)
                {
                    int randi = random.Next(minimum, maximum + 1);
                    arraySet.Add(randi);
                    i++;
                    filled = (i == size);
                }
            }
            return arraySet;
        }

        /// <summary>
        /// Method to determine if a List contains uniques elements
        /// </summary>
        /// <param name="arraySet">The data set to test</param>
        /// <returns>true if the elements are unique, false otherwise</returns>
        public static bool IsUnique(List<int> arraySet)
        {
            bool isUniqueflag = true;

            for (int i = 0; i < arraySet.Count && isUniqueflag; i++)
            {
                for (int j = i + 1; j < arraySet.Count && isUniqueflag; j++)
                {
                    isUniqueflag = arraySet[i] != arraySet[j];
                }
            }
            return isUniqueflag;
        }


        /// <summary>
        ///  Determines the common elements(intersection) between setA and setB
        /// </summary>
        /// <param name="setA">The first of the two Sets</param>
        /// <param name="setB">The second of the two sets</param>
        /// <returns>a new set that consists of the common elements that exist in both A and B</returns>
        public static List<int> Intersection(List<int> setA, List<int> setB)
        {
            List<int> setCommon = new List<int>();
            if (setA.Count == 0 || setB.Count == 0)
            {
                throw new ArgumentException("Arraylist arguments cannot be empty");
            }
            for (int i = 0; i < setA.Count; i++)
            {
                for (int j = 0; j < setA.Count; j++)
                {
                    if (setA[i] == setB[j])
                    {
                        bool canAddToCommon = true;
                        for (int k = 0; k < setCommon.Count; k++)
                        {
                            if (setA[i] == setCommon[k])
                            {
                                canAddToCommon = false;
                                break;
                            }
                        }
                        if (canAddToCommon)
                        {
                            setCommon.Add(setA[i]);
                        }
                    }
                }
            }

            return setCommon;
        }

        /// <summary>
        /// Determine the Union of two sets
        /// </summary>
        /// <param name="setA">the first of the two sets for the Union</param>
        /// <param name="setB">the second of the two sets for the Union</param>
        /// <returns>a new set that consists of the Union between setA and setB</returns>
        public static List<int> Union(List<int> setA, List<int> setB)
        {
            List<int> uniqueSet = new List<int>();
            if (setA.Count == 0 || setB.Count == 0)
            {
                throw new ArgumentException("Arraylist arguments cannot be empty");
            }

            for (int i = 0; i < setA.Count; i++)
            {
                bool canAddToUnique = true;
                for (int j = 0; j < uniqueSet.Count && canAddToUnique; j++)
                {
                    canAddToUnique = setA[i] != uniqueSet[j];
                }
                if (canAddToUnique)
                {
                    uniqueSet.Add(setA[i]);
                }
            }

            for (int i = 0; i < setB.Count; i++)
            {
                bool canAddToUnique = true;
                for (int j = 0; j < uniqueSet.Count && canAddToUnique; j++)
                {
                    canAddToUnique = setB[i] != uniqueSet[j];
                }
                if (canAddToUnique)
                {
                    uniqueSet.Add(setB[i]);
                }
            }

            return uniqueSet;
        }


        /// <summary>
        /// Determines if setB is a SubSet of setA
        /// </summary>
        /// <param name="setA">the full set for the comparison</param>
        /// <param name="setB">the sub set to be tested</param>
        /// <returns>true if setB is a SubSet of setA</returns>
        public static bool SubSet(List<int> setA, List<int> setB)
        {
            if (setA.Count == 0 || setB.Count == 0)
            {
                throw new ArgumentException("Arraylist arguments cannot be empty");
            }
            if (setA.Count < setB.Count)
            {
                throw new ArgumentException("Set A cannot be smaller than set B");
            }

            bool isInSet = true;
            for (int i = 0; i < setA.Count && isInSet; i++)
            {
                isInSet = false;
                for (int j = 0; j < setB.Count && !isInSet; j++)
                {
                    isInSet = setA[i] == setB[j];
                }
            }

            return isInSet;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Must use Test facility (Test/Run/All Tests) to run the units Tests");
            Console.WriteLine("Hit any key to close...");
            Console.ReadLine();
        }
    }
}
