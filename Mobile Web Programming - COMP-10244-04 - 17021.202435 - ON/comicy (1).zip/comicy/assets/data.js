// Data was pulled as CSV data from here: https://open.hamilton.ca/
// and then converted to JSON data with this tool: https://www.convertcsv.com/csv-to-json.htm

let charLocation = [
 {
   "X": 583105.5694,
   "Y": 4786343.8009,
   "NAME": "The Joker",
   "TYPE": "Villain",
   "DESCRIPTION": "A complete psychopath with no moral compass whatsoever, the Joker, whose real name and identity remain completely unknown, is characterized by his chalk-white skin, green hair and a permanent rictus grin stretched across his face.",
   "LONGITUDE": "-79.97666063192372",
   "LATITUDE": "43.22530917335925",
   "ADDRESS": "300 WIlson Street East",
   "IMAGE": "joker.jpg",
   "COMMUNITY": "Ancaster"
 },
 {
   "X": 594054.5425,
   "Y": 4790121.25,
   "NAME": "Dr. Octopus",
   "TYPE": "Villain",
   "DESCRIPTION": "Dr. Otto Octavius is a highly intelligent and prideful scientist, better known as the criminal mastermind Doctor Octopus. During an atomic research project, Octavius' body was fused to four mechanical, tentacle-like arms, also causing him severe brain damage that turned him into a criminal.",
   "LONGITUDE": "-79.84121898077925",
   "LATITUDE": "43.258031699157776",
   "ADDRESS": "571 Barton Street East",
   "IMAGE": "octo.jpg",
   "COMMUNITY": "Hamilton"
 },
 {
   "X": 597338.2526,
   "Y": 4775024.8248,
   "NAME": "Doom",
   "TYPE": "Villain",
   "DESCRIPTION": "Von Doom is scarred after a machine he invents explodes, leading him to wear a mask and suit of armor. He later becomes monarch of Latveria and seeks world domination.",
   "LONGITUDE": "-79.80342947186979",
   "LATITUDE": "43.1217043785817",
   "ADDRESS": "2641 Regional Road 56",
   "IMAGE": "doom.jpg",
   "COMMUNITY": "Glanbrook"
 },
 {
   "X": 582514.8299,
   "Y": 4805301.4837,
   "NAME": "Poison Ivy",
   "TYPE": "Villain",
   "DESCRIPTION": "Ivy is considered extremely beautiful within the DC Universe, and is often presented as a temptress. She is typically depicted barefoot with long flowing hair, plant vines extending over her limbs, and a green one-piece suit adorned with leaves, with occasional variations to her skin tone.",
   "LONGITUDE": "-79.98108621069434",
   "LATITUDE": "43.396053385940036",
   "ADDRESS": "1496 Centre Road",
   "IMAGE": "poivy.jpg",
   "COMMUNITY": "Flamborough"
 },
 {
   "X": 593256.6728,
   "Y": 4788223.0529,
   "NAME": "Kingpin",
   "TYPE": "Villain",
   "DESCRIPTION": "Across all iterations, the Kingpin is depicted with an extraordinarily heavyset appearance and a bald head. The character is not simply obese but also heavily-muscled (like a sumo wrestler) and a formidable hand-to-hand combatant.",
   "LONGITUDE": "-79.85136825137424",
   "LATITUDE": "43.24104159893363",
   "ADDRESS": "565 Concession Street",
   "IMAGE": "pin.png",
   "COMMUNITY": "Hamilton"
 },
 {
   "X": 584813.0508,
   "Y": 4790827.1734,
   "NAME": "Spiderman",
   "TYPE": "Hero",
   "DESCRIPTION": "American teenager Peter Parker, a poor sickly orphan, is bitten by a radioactive spider. As a result of the bite, he gains superhuman strength, speed, and agility, along with the ability to cling to walls, turning him into Spider-Man.",
   "LONGITUDE": "-79.95494871190127",
   "LATITUDE": "43.2654838918564",
   "ADDRESS": "18 Ogilvie Street",
   "IMAGE": "spiderman.jpg",
   "COMMUNITY": "Dundas"
 },
 {
   "X": 577841.2703,
   "Y": 4805454.8116,
   "NAME": "Batman",
   "TYPE": "Hero",
   "DESCRIPTION": "Batman is a crimefighter operating in Gotham City, he serves as its protector, using the symbol of a bat to strike fear into the hearts of criminals. Unlike other superheroes, Batman is often depicted to lack any superpowers, instead using lifelong training and equipment to fight crime.",
   "LONGITUDE": "-80.03876645340884",
   "LATITUDE": "43.39793340863621",
   "ADDRESS": "1803 Brock Road",
   "IMAGE": "batman1.jpg",
   "COMMUNITY": "Flamborough"
 },
 {
   "X": 581458.25,
   "Y": 4791874.15,
   "NAME": "Superman",
   "TYPE": "Hero",
   "DESCRIPTION": "Superman is known for his superhuman strength, his ability to jump large distances, and his wide range of other powers. These powers come from his alien background; he was born on the planet Krypton.",
   "LONGITUDE": "-79.99612469236381",
   "LATITUDE": "43.2752802704378",
   "ADDRESS": "59 Kirby Avenue",
   "IMAGE": "superman.jpg",
   "COMMUNITY": "Flamborough"
 },
 {
   "X": 591660.3011,
   "Y": 4790189.5476,
   "NAME": "Captain America",
   "TYPE": "Hero",
   "DESCRIPTION": "Recipient of the Super Soldier serum, World War II hero Steve Rogers fights for American ideals as one of the world's mightiest heroes and the leader of the Avengers. America's World War II Super-Soldier continues his fight in the present as an Avenger and untiring sentinel of liberty.",
   "LONGITUDE": "-79.87069971542475",
   "LATITUDE": "43.25894156052855",
   "ADDRESS": "55 York Boulevard",
   "IMAGE": "catpain.jpg",
   "COMMUNITY": "Hamilton"
 },
 {
   "X": 596705.5265,
   "Y": 4788544.1777,
   "NAME": "Dr. Strange",
   "TYPE": "Hero",
   "DESCRIPTION": "A Master of the Mystic Arts, Doctor Strange has phenomenally powerful magical abilities that enable him to skillfully conjure myriad spells. Strange has been able to use his spells to bind opponents and create complex shields and barriers, among many other uses for both defense and attack.",
   "LONGITUDE": "-79.80884162904492",
   "LATITUDE": "43.24349823689495",
   "ADDRESS": "103 Kenilworth Avenue North",
   "IMAGE": "strange.jpg",
   "COMMUNITY": "Hamilton"
 }
];

export { charLocation };