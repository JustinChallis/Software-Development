const sportsfield = [
{
    "X": 592904.0574,
    "Y": 4783435.1947,
    "OBJECTID": 1,
    "TYPE": "Baseball",
    "REC_AREA": "Hamilton Mountain",
    "OWNERSHIP": "City",
    "WEBSITE": "https://www.hamilton.ca/",
    "COMMENTS": "",
    "DETAILS": "This Diamond is located at the southwest of Eleanor Park",
    "LONGITUDE": -79.856516428775805,
    "LATITUDE": 43.1979802919438
},

{
    "X": 592989.0895,
    "Y": 4783405.9471,
    "OBJECTID": 2,
    "TYPE": "Basketball",
    "REC_AREA": "Hamilton Mountain",
    "OWNERSHIP": "City",
    "WEBSITE": "https://www.hamilton.ca/",
    "COMMENTS": "",
    "DETAILS": "This Court is located at the southeast of Eleanor Park",
    "LONGITUDE": -79.855474961656697,
    "LATITUDE": 43.197706511898403
},

{
    "X": 592488.4619,
    "Y": 4787746.9553,
    "OBJECTID": 3,
    "TYPE": "Baseball",
    "REC_AREA": "Hamilton Mountain",
    "OWNERSHIP": "City",
    "WEBSITE": "https://www.hamilton.ca/",
    "COMMENTS": "",
    "DETAILS": "This Diamond is located at the northwest of Inch Park",
    "LONGITUDE": -79.860908234260293,
    "LATITUDE": 43.236849931375097
},

{
    "X": 592452.1369,
    "Y": 4787654.7038,
    "OBJECTID": 4,
    "TYPE": "Baseball",
    "REC_AREA": "Hamilton Mountain",
    "OWNERSHIP": "City",
    "WEBSITE": "https://www.hamilton.ca/",
    "COMMENTS": "",
    "DETAILS": "This Diamond is located at the southwest of Inch Park",
    "LONGITUDE": -79.861370993708505,
    "LATITUDE": 43.236023850524496
},

{
    "X": 594839.7626,
    "Y": 4786978.8113,
    "OBJECTID": 5,
    "TYPE": "Basketball",
    "REC_AREA": "Hamilton Mountain",
    "OWNERSHIP": "City",
    "WEBSITE": "https://www.hamilton.ca/",
    "COMMENTS": "",
    "DETAILS": "This Court is located at the northwest of Highview Park",
    "LONGITUDE": -79.83208742651,
    "LATITUDE": 43.229642456953499
},

{
    "X": 592598.6634,
    "Y": 4787600.3087,
    "OBJECTID": 6,
    "TYPE": "Baseball",
    "REC_AREA": "Hamilton Mountain",
    "OWNERSHIP": "City",
    "WEBSITE": "https://www.hamilton.ca/",
    "COMMENTS": "",
    "DETAILS": "This Diamond is located at the southeast corner of Inch Park",
    "LONGITUDE": -79.859575875321895,
    "LATITUDE": 43.235516160749803
},

{
    "X": 592610.8248,
    "Y": 4787649.7457,
    "OBJECTID": 7,
    "TYPE": "Baseball",
    "REC_AREA": "Hamilton Mountain",
    "OWNERSHIP": "City",
    "WEBSITE": "https://www.hamilton.ca/",
    "COMMENTS": "",
    "DETAILS": "dThis Diamond is located at the east of Inch Park between two other diamonds",
    "LONGITUDE": -79.859417825384199,
    "LATITUDE": 43.235959745541201
},

{
    "X": 592627.2048,
    "Y": 4787691.2486,
    "OBJECTID": 8,
    "TYPE": "Baseball",
    "REC_AREA": "Hamilton Mountain",
    "OWNERSHIP": "City",
    "WEBSITE": "https://www.hamilton.ca/",
    "COMMENTS": "",
    "DETAILS": "This Diamond is located at the northeast of Inch Park",
    "LONGITUDE": -79.859209159774807,
    "LATITUDE": 43.236331381854001
},

{
    "X": 591735.3339,
    "Y": 4787927.7459,
    "OBJECTID": 9,
    "TYPE": "Baseball",
    "REC_AREA": "Hamilton Mountain",
    "OWNERSHIP": "City",
    "WEBSITE": "https://www.hamilton.ca/",
    "COMMENTS": "",
    "DETAILS": "This Diamond is located at the southeast of Bruce Park",
    "LONGITUDE": -79.870151937840205,
    "LATITUDE": 43.238569558456099
},

{
    "X": 591659.3894,
    "Y": 4787901.5006,
    "OBJECTID": 10,
    "TYPE": "Baseball",
    "REC_AREA": "Hamilton Mountain",
    "OWNERSHIP": "City",
    "WEBSITE": "https://www.hamilton.ca/",
    "COMMENTS": "",
    "DETAILS": "This Diamond is located at the southwest of Bruce Park",
    "LONGITUDE": -79.871091484435595,
    "LATITUDE": 43.238342506582697
}


    
]
 